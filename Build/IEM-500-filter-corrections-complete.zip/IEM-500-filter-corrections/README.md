# IEM-500 Filter Correction Suite

Reference implementation accompanying the research paper
*High-Pass and Low-Pass Modeling Failures in Inductor EQ Emulations.*

---

## Status

**Research scaffold.** This repository separates the documented architectural
hypothesis from what is actually implemented. It does not claim a measured
hardware clone.

### Implemented

- Independent high-pass stage whose state survives EQ bypass.
- Second-order digital HPF and LPF reference sections with bilinear frequency
  prewarping, including an optional high-shelf mode.
- Bounded, direction-aware Jiles-Atherton-style hysteresis experiment with a
  numerically stable Langevin evaluation.
- Streaming polyphase-FIR oversampler with a single-sample API.
- CMake build and a seven-case regression test suite.

### Not yet implemented, not verified

- A topology-complete passive LC wave digital filter network identified from
  measured component values.
- A validated, transformer-specific Jiles-Atherton parameter set.
- A full implicit Newton Jiles-Atherton solver.
- A production-quality resampler with verified alias rejection figures.
- Hardware null-test agreement.
- Host and plugin validation.

These distinctions are intentional. A code module is not treated as proof of
hardware equivalence.

---

## Neutral terminology

| Term | Meaning |
|---|---|
| `IEM-500` | Neutral identifier for the reference inductor EQ architecture studied in the paper |
| `kHpfCorner` | Fixed high-pass corner used by the reference architecture |
| `kLpfCorner` | Selectable low-pass or filter corner |
| `moduleBypass` | EQ band bypass control |
| `couplingTransformer` | Generic input and output transformer stage |
| `inductorNetwork` | Generic passive LC network under investigation |

No manufacturer or model attribution is required by this repository.

---

## Signal-flow invariant

```text
input
  |
  v
[ HPF ]              <-- always in the signal path
  |
  v
[ moduleBypass ? ] -- true --> transformer --> output
  |
 false
  v
[ EQ / LPF bands ]
  |
  v
[ transformer ]      <-- nonlinear / magnetic, oversampled
  |
  v
output
```

The critical software rule is that toggling moduleBypass must not remove or
reset the high-pass state.

---

Repository layout

```text
IEM-500-filter-corrections/
├── README.md
├── CMakeLists.txt
├── include/
│   ├── HpfSection.h
│   ├── LpfSection.h
│   ├── JilesAtherton.h
│   ├── Oversampler.h
│   └── FilterChain.h
├── src/
│   ├── HpfSection.cpp
│   ├── LpfSection.cpp
│   ├── JilesAtherton.cpp
│   ├── Oversampler.cpp
│   └── FilterChain.cpp
├── test/
│   └── test_suite.cpp
└── docs/
    ├── paper-update.md
    └── signal-flow.md
```

---

Build

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

No external DSP framework is required. Only the C++ standard library is used.

---

Validation policy

The paper should report only measurements that have actually been executed.
Recommended future validation:

1. Compare the digital HPF against an independently solved analog prototype.
2. Measure the bypass-state transfer function with the HPF held constant.
3. Identify transformer hysteresis parameters from measured major and minor
   loops.
4. Measure alias rejection using a high-level swept nonlinear excitation.
5. Compare the complete chain against hardware using aligned level, phase, and
   null tests.

Until those experiments exist, treat every accuracy claim as UNVERIFIED.

---

License and notice

Research and educational implementation. No affiliation, endorsement, or
sponsorship by a hardware manufacturer is claimed. All trademarks referenced
implicitly by the underlying subject matter remain the property of their
respective owners and are deliberately not reproduced here.
