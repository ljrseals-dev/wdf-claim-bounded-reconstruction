# IEM-500 Signal Flow

```text
input
  |
  v
+-----------------------------+
| HPF                         |
| independent of moduleBypass |
+-------------+---------------+
              |
              v
       +--------------+
       | moduleBypass |
       +------+-------+
              |
        +-----+-----+
        |           |
       true        false
        |           |
        |     +-----v------+
        |     | EQ filters |
        |     +-----+------+
        |           |
        +-----+-----+
              |
              v
      nonlinear / magnetic
         (oversampled)
              |
              v
            output
```

---

State rule

A bypass transition must not reset the high-pass state. A production
implementation should also preserve constant latency across bypass states
whenever a latency-bearing oversampled path is introduced.

---

Current implementation note

The repository provides a reference digital HPF and LPF implementation, a
bounded experimental magnetic model, and a streaming polyphase-FIR
oversampler. A topology-complete wave digital filter implementation remains a
separate work item and must be validated against an independently solved
analog network before any hardware-equivalence claim is made.
